public class Test3 {
    public static void main(String[] args){
        Duck duck=new Duck("鸭子","发烧","感冒",2);
        duck.showSymptom();
    }
}
