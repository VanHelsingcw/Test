public class Duck extends Poultry {
    Duck(){}
    Duck(String name,String symptom,String illness,int age){
        setName(name);
        setSymptom(symptom);
        setIllness(illness);
        setAge(age);
    }
    public void showSymptom(){
        System.out.println("动物种类:"+getName()+",年龄:"+getAge()+"岁");
        System.out.println("入院原因:"+getIllness());
        System.out.println("症状为:"+getSymptom());
    }
}
