public class Test7 {
    public static void main(String[] args){
        int[] a={1,2,3,4,3,2,1};
        int[] b={1,2,3,4,3,2,1};
        equals(a,b);
    }
    public static void equals(int[] a,int[] b){
        int m,n;
        m=n=0;
        if(a.length==b.length){
            for(;m<a.length;m++,n++){
                if(a[m]!=b[n]){
                    System.out.print("["+a[0]);
                    for(int j=1;j<7;j++){
                        System.out.print(","+a[j]);
                    }
                    System.out.println("]");
                    System.out.print("["+b[0]);
                    for(int j=1;j<7;j++){
                        System.out.print(","+b[j]);
                    }
                    System.out.println("]");
                    System.out.println("是否一致:false");
                }
                if(m==a.length-1){
                    System.out.print("["+a[0]);
                    for(int j=1;j<7;j++){
                        System.out.print(","+a[j]);
                    }
                    System.out.println("]");
                    System.out.print("["+b[0]);
                    for(int j=1;j<7;j++){
                        System.out.print(","+b[j]);
                    }
                    System.out.println("]");
                    System.out.println("是否一致:true");
                }
            }
        }
    }
}
