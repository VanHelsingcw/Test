public class Test3 {
    public static void main(String[] args){
        String a[]=new String[]{"黑桃","红桃","梅花","方片"};
        String b[]=new String[]{"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
        String c[]=new String[52];
        int k=0;
        for(int i=0;i<4;i++){
            for(int j=0;j<13;j++){
                c[k]=a[i]+b[j];
                k++;
            }
        }
        System.out.print(c[0]+" "+c[4]+" "+c[49]);
    }
}
