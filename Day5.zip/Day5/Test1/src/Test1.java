public class Test1 {
    public static void main(String[] args){
        int[] Num=new int[]{10,20,30,40,50,60,66,70,80,99};
        System.out.println("您的大乐透号码为：");
        for(int i=0;i<10;i++){
            System.out.print(Num[i]+" ");
        }
    }
}
