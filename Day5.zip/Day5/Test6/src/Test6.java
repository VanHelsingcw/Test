public class Test6 {
    public static void main(String[] args){
        int[] a={1,2,3,4,3,2,1};
        int[] b={1,2,3,4,5,2,1};
        sym(a);
        sym(b);
    }
    public static void sym(int[] arr){
        int m,n;
        m=0;n=6;
        for(int i=0;i<7;i++){
            if(arr[m]!=arr[n]){
                System.out.print("["+arr[0]);
                for(int j=1;j<7;j++){
                    System.out.print(","+arr[j]);
                }
                System.out.println("] 是否对称:false");
                break;
            }
            m++;n--;
            if(m==n){
                System.out.print("["+arr[0]);
                for(int k=1;k<7;k++){
                    System.out.print(","+arr[k]);
                }
                System.out.println("] 是否对称:true");
            }
        }
    }
}
