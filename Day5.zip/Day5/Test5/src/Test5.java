public class Test5 {
    public static void main(String[] args){
        int[] arr={95,92,75,56,98,71,80,58,91,91};
        getAvg(arr);
    }
    public static void getAvg(int[] arr){
        int sum,avg,num;
        sum=num=avg=0;
        for(int i=0;i<10;i++){
            sum+=arr[i];
        }
        avg=sum/10;
        for(int i=0;i<10;i++){
            if(arr[i]>avg)
                num++;
        }
        System.out.print("高于平均分:"+avg+"的个数有"+num+"个");
    }
}
