public class Test4 {
    public static void main(String[] args){
        char[] arr=new char[]{'a','l','f','m','f','o','b','b','s','n'};
        printCount(arr);
    }
    public  static void printCount(char arr[]){
        int[] a=new int[26];
        char[] b=new char[]{'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        for(int i=0;i<10;i++){
            for(int j=0;j<26;j++){
                if(arr[i]==b[j]) {
                    a[j] = a[j] + 1;
                }
            }
        }
        for(int k=0;k<26;k++){
            if(a[k]!=0){
                System.out.println(b[k]+"--"+a[k]);
            }
        }
    }
}
