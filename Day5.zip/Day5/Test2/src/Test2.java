public class Test2 {
    public static void main(String[] args){
        String a[]=new String[]{"黑桃","红桃","梅花","方片"};
        String b[]=new String[]{"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
        for(int i=0;i<4;i++){
            for(int j=0;j<13;j++){
                System.out.print(a[i]+b[j]+" ");
            }
            System.out.println();
        }
    }
}
