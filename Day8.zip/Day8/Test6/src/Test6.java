import java.util.ArrayList;
import java.util.Scanner;

public class Test6 {
    public static void main(String[] args){
        ArrayList<String> list=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        System.out.println("请输入你要输入字符串的个数:");
        int k=sc.nextInt();
        System.out.println("请开始输入你要输入的字符串:");
        for(int i=0;i<=k;i++){
            String s=sc.nextLine();
            list.add(s);
        }
        System.out.println("源字符串:");
        System.out.print("["+list.get(1));
        for(int m=2;m<list.size();m++){
            System.out.print(","+list.get(m));
        }
        System.out.println("]");
        for(int j=0;j<list.size();j++){
            if(list.get(j).length()>5){
                list.remove(j);
                j--;
            }
        }
        System.out.println("删除后:");
        System.out.print("["+list.get(1));
        for(int n=2;n<list.size();n++){
            System.out.print(","+list.get(n));
        }
        System.out.println("]");
    }
}
