import java.util.Scanner;
public class Test4 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.print("请输入源字符串:");
        String s=sc.nextLine();
        System.out.print("请输入要删除的字符串:");
        String s1=sc.nextLine();
        int index=0;
        int count=0;
        while((index=s.indexOf(s1,index))!= -1){
                index+=s1.length();
                count++;
        }
        System.out.println("源字符串中总共包含:"+count+"个"+s1+",");
        String s2=s.replace(s1,"");
        System.out.println("删除"+s1+"后的字符串为:"+s2);
    }
}
