import java.util.Scanner;

public class Test7 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.print("请输入一个字符串:");
        String s=sc.nextLine();
        char[] c=s.toCharArray();
        int f=0;
        int r=s.length()-1;
        for(;c[f]==c[r]&&f<=r;f++,r--){
            if(f>=r){
                System.out.println("回文数:true");
            }
        }
        if(c[f]!=c[r]){
            System.out.println("回文数:false");
        }
    }
}
