public class Circle {
        private int r;
        public Circle(){}
        public Circle(int r){
            this.r=r;
        }
        public void set(int r){
            this.r=r;
        }
        public void showArea(){
            double S;
            S=3.14*r*r;
            System.out.println("圆的面积为:"+S);
        }
        public void showPerimeter(){
            double C;
            C=2*3.14*r;
            System.out.println("圆的周长为:"+C);
        }

}
