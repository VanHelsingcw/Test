public class Test1 {
    public static void main(String[] args){
        Circle c=new Circle();
        Circle d=new Circle(8);
        c.set(8);
        c.showArea();
        d.showArea();
    }
}

