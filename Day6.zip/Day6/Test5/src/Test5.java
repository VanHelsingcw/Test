public class Test5 {
    public static void main(String[] args){
        Coder c=new Coder("陈炜",1,10000);
        Manager m=new Manager("陈炜",2,10000,10000);
        c.intro();
        c.showSalary();
        c.work();
        m.intro();
        m.showSalary();
        m.work();
    }
}
