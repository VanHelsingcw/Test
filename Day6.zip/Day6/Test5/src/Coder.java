public class Coder {
    private String name;
    private int num;
    private int wage;
    public Coder(){}
    public Coder(String name,int num,int wage){
        this.name=name;
        this.num=num;
        this.wage=wage;
    }
    public void set(String name,int num,int wage){
        this.name=name;
        this.num=num;
        this.wage=wage;
    }
    public void intro(){
        System.out.println("姓名:"+name+" 工号:"+num);
    }
    public void showSalary(){
        System.out.println("工资:"+wage);
    }
    public void work(){
        System.out.println("一名程序员");
    }
}
