public class Manager{
    private String name;
    private int num;
    private int wage;
    public Manager(){}
    public Manager(String name,int num,int basic,int bonus){
        this.name=name;
        this.num=num;
        this.wage=basic+bonus;
    }
    public void set(String name,int num,int basic,int bonus){
        this.name=name;
        this.num=num;
        this.wage=basic+bonus;
    }
    public void intro(){
        System.out.println("姓名:"+name+" 工号:"+num);
    }
    public void showSalary(){
        System.out.println("工资:"+wage);
    }
    public void work(){
        System.out.println("一名管理员");
    }
}
