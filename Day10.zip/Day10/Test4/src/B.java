public class B implements A{
    @Override
    public void showA() {
        System.out.println("AAA");
    }
    public static void showD(){
        System.out.println("DDDD");
    }
}
