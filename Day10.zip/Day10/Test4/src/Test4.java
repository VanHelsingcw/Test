public class Test4 {
    public static void main(String[] args){
        A.showB10("BBBB");
        A.showC10("CCCC");
        B b=new B();
        b.showA();
        B.showD();
    }
}
