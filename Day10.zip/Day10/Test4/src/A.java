public interface A {
    public abstract void showA();
    private static void show10(String str){
        System.out.println("static "+str);
        for(int i=0;i<10;i++){
            System.out.print(str+" ");
        }
        System.out.println();
    }
    public static void showB10(String str){
        show10(str);
    }
    public static void showC10(String str){
        show10(str);
    }
}
