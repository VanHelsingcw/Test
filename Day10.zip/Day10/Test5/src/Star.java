public class Star {
    public void shine(){
        System.out.println("star:星星一闪一闪亮晶晶");
        System.out.println("=================");
    }
}
