public interface Universe {
    public abstract void doAnything();
}
