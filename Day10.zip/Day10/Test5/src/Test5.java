public class Test5 {
    public static void main(String[] args){
        Star a=new Star();
        a.shine();
        Sun b=new Sun();
        b.doAnything();
        Star c=new Sun();
        c.shine();
    }
}
