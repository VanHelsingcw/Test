public class Test4 {
    public static void main(String[] args){
        Worker worker=new Worker();
        Apple a=new Apple(5,"青色");
        Apple b=new Apple(3,"红色");
        worker.pickApple(new Compare(),a,b);
        worker.pickApple(new Compare1(),a,b);
    }
}
