public class Compare1 implements CompareAble {
    public void compare(Apple a,Apple b){
        System.out.println("默认挑大的:");
        if(a.getSize()>=b.getSize()){
            System.out.println(a.getSize()+".0-"+a.getColor());
        }
        else {
            System.out.println(b.getSize()+".0-"+b.getColor());
        }
    }
}
