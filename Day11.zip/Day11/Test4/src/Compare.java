public class Compare implements CompareAble {
    @Override
    public void compare(Apple a, Apple b) {
        if(a.getColor()=="红色"){
            System.out.println("挑红的:");
            System.out.println(a.getSize()+".0-"+a.getColor());
        }
        if(b.getColor()=="红色"){
            System.out.println("挑红的:");
            System.out.println(b.getSize()+".0-"+b.getColor());
        }
    }
}
