public interface CompareAble {
    public default void compare(Apple a,Apple b){}
}
