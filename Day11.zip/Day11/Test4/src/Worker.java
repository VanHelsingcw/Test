public class Worker {
    public void pickApple(CompareAble c,Apple a,Apple b){
        c.compare(a,b);
    }
}
