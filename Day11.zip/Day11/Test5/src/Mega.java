public class Mega implements FightAble {
    @Override
    public void specialFight() {
        System.out.println("法术攻击");
    }
}
