public class Player {
    public void select(String str){
        if(str=="法力角色"){
            Mega mega=new Mega();
            System.out.println("选择:"+str);
            mega.specialFight();
            mega.commonFight();
        }
        if(str=="武力角色"){
            Warrior warrior=new Warrior();
            System.out.println("选择:"+str);
            warrior.specialFight();
            warrior.commonFight();
        }
    }
}
