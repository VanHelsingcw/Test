public class Test5 {
    public static void main(String[] args){
        Player a=new Player();
        a.select("法力角色");
        System.out.println("============");
        Player b=new Player();
        b.select("武力角色");
    }
}
