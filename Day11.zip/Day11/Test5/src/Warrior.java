public class Warrior implements FightAble {
    @Override
    public void specialFight() {
        System.out.println("武器攻击");
    }
}
