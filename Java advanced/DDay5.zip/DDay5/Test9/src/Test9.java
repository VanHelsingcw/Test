public class Test9 {
    public static void main(String[] args) {
        System.out.println("主线程开始啦");
        Mythread mythread=new Mythread("子线程开始啦");
        mythread.start();
        for( int i=2;i<=100;i+=2){
            System.out.println(i);
        }
    }
}
