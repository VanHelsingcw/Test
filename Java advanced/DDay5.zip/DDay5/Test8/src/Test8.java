public class Test8 {
    public static void main(String[] args) {
        Student student=new Student("陈炜",30,0);
        try {
            student.setScore(-1);
        }catch (ScoreException e){
            e.printStackTrace();
        }
    }
}
