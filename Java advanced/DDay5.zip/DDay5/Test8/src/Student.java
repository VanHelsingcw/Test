public class Student {
    private String name;
    private int number;
    private int score;
    public  Student(String name,int number,int score){
        this.name=name;
        this.number=number;
        this.score=score;
    }

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }

    public int getScore() {
        return score;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setScore(int score) throws ScoreException{
        if(score<0){
            throw new ScoreException("分数不能为负数哦");
        }
        else {
            this.score = score;
        }
    }
}
