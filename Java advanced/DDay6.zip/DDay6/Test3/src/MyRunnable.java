public class MyRunnable implements Runnable {
    @Override
    public void run() {
        String threadName=Thread.currentThread().getName();
        for(int i=0;i<3;i++){
            System.out.println(threadName+"正在执行");
        }
    }
}
