public class Test3 {
    public static void main(String[] args) {
        MyRunnable myRunnable=new MyRunnable();
        Thread thread=new Thread(myRunnable,"子线程");
        thread.start();
        String threadName=Thread.currentThread().getName();
        for(int i=0;i<3;i++){
            System.out.println(threadName+"正在执行");
        }
    }
}
