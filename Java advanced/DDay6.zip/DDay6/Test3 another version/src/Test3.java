public class Test3 {
    public static void main(String[] args) {
        MyThread myThread=new MyThread("子线程");
        myThread.start();
        String threadname=Thread.currentThread().getName();
        for(int i=0;i<3;i++){
            System.out.println(threadname+"正在执行");
        }
    }
}
