public class MyThread extends Thread {
    public MyThread(){};
    public MyThread(String name){
        super(name);
    }
    @Override
    public void run() {
        String threadname=Thread.currentThread().getName();
        for(int i=0;i<3;i++){
            System.out.println(threadname+"正在执行");
        }
    }
}
