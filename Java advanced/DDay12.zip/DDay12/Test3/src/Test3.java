public class Test3 {
    public static void decToHex(int num ,NumberToString nts){
        System.out.println(nts.convert(num));
    }

    public static void main(String[] args) {
        decToHex(100,Integer::toHexString);//或者可以写成Lambda形式：s->Integer.toHexString(s);
    }
}
