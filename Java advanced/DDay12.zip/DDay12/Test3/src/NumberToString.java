@FunctionalInterface
public interface NumberToString {
    String convert(int num);
}
