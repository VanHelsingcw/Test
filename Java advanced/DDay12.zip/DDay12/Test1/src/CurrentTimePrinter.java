@FunctionalInterface
public interface CurrentTimePrinter {
    void printCurrentTime();
}
