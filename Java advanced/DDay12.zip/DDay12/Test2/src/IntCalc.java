@FunctionalInterface
public interface IntCalc {
    int calc(int a , int b);
}
