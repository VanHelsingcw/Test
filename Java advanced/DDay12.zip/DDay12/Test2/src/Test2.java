public class Test2 {
    static void getProduct(int a , int b ,IntCalc calc){
        int value=calc.calc(a,b);
        System.out.println(a+"和"+b+"的乘积为:"+value);
    }

    public static void main(String[] args) {
        getProduct(7,30,(a,b)->a*b);
    }
}
