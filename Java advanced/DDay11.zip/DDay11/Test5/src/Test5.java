import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Test5 {
    public static void main(String[] args) throws IOException {
        Socket client=new Socket("127.0.0.1",8888);
        BufferedOutputStream bos=new BufferedOutputStream(client.getOutputStream());
        byte[] b="hello.服务器,我是客户端. ".getBytes();
        bos.write(b);
        bos.flush();
        client.close();
        bos.close();
    }
}
