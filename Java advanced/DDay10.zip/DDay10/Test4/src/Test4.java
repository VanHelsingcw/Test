import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Test4 {
    public static void main(String[] args) throws IOException {
        BufferedReader br=new BufferedReader(new FileReader("C:\\Users\\ASUS\\Desktop\\b.txt"));
        String string;
        Scanner sc=new Scanner(System.in);
        System.out.println("请输入验证码:");
        String str=sc.nextLine();
        while((string=br.readLine())!=null){
            if(str.equals(string)){
                System.out.println("验证成功");
                break;
            }
        }
        if(string==null){
            System.out.println("验证失败");
        }
        br.close();
    }
}
