import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class Test6 {
    public static void main(String[] args) throws IOException {
        InputStreamReader ir=new InputStreamReader(new FileInputStream("C:\\Users\\ASUS\\Desktop\\a.txt"));
        int b;
        while((b=ir.read())!=-1){
            System.out.print((char)b);
        }
        ir.close();
    }
}
