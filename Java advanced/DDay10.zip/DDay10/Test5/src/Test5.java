import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class Test5 {
    public static void main(String[] args) throws IOException {
        OutputStreamWriter ow=new OutputStreamWriter(new FileOutputStream("C:\\Users\\ASUS\\Desktop\\a.txt"),"GBK");
        ow.write("我爱 Java");
        ow.close();
    }
}
