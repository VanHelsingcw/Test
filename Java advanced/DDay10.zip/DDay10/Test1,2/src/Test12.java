import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test12 {
    public static void main(String[] args) throws IOException {
        String Filename="C:\\Users\\ASUS\\Desktop\\c.txt";
        BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(Filename));
        byte[] c="\r\n".getBytes();
        bos.write(97);
        bos.write(c);
        byte[] b="i love java".getBytes();
        bos.write(b);
        bos.write(c);
        bos.close();
    }
}
