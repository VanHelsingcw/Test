import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Test6 {
    public static void main(String[] args){
        Map<Integer,String> map=new HashMap<>();
        map.put(1, "张三丰");
        map.put(2, "周芷若");
        map.put(3, "汪峰");
        map.put(4, "灭绝师太");
        Set<Map.Entry<Integer,String>> set=map.entrySet();
        for(Map.Entry<Integer,String> entry:set){
            Integer a=entry.getKey();
            String b=entry.getValue();
            System.out.print("序号:"+a+" 姓名:"+b+" ");
        }
        System.out.println();
        map.put(5,"李晓红");
        map.remove(1);
        map.put(2,"周林");
        for(Map.Entry<Integer,String> entry:set){
            Integer a=entry.getKey();
            String b=entry.getValue();
            System.out.print("序号:"+a+" 姓名:"+b+" ");
        }
        System.out.println();
    }
}
