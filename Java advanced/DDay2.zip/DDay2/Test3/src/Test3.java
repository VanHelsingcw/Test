import java.util.ArrayList;
import java.util.Iterator;

public class Test3 {
    public static void main(String[] args){
        int[] a={0,1,2,3,4,5,6,7};
        ArrayList<Integer> b=new ArrayList<>();
        for(int i=0;i<a.length;i++){
            b.add(a[i]);
        }
        Iterator<Integer> c=b.iterator();
        while(c.hasNext()){
            Integer d=c.next();
            System.out.println(d);
        }
    }
}
