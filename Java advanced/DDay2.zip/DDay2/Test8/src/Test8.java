import java.util.ArrayList;

public class Test8 {
    public static void main(String[] args){
        ArrayList<Integer> a=new ArrayList<>();
        Integer b=7;
        for(int i=0;i<=10;i++){
            a.add(i);
        }
        int c=listTest(a,b);
        System.out.println(c);
    }
    public static int listTest(ArrayList<Integer> al,Integer s){
        if(al.indexOf(s)==-1){
            return -1;
        }
        else return al.indexOf(s);
    }
}
