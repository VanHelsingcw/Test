import java.io.File;

public class Test4 {
    public static void main(String[] args) {
        File f1=new File("D:\\ccc");
        f1.mkdir();
        File f2=new File("D:\\ccc\\bbb");
        f2.mkdir();
        File f3=new File("D:\\ccc\\bbb\\aaa");
        f3.mkdir();
    }
}
