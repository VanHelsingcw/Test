import java.io.File;

public class Test8 {
    public static void main(String[] args) {
        File dir=new File("C:\\Users\\ASUS\\Desktop\\Java程序作业");
        File[] files=dir.listFiles();
        for(File file:files){
            if(file.isFile()){
                System.out.println("文件名:"+file.getName());
            }
        }
    }
}
