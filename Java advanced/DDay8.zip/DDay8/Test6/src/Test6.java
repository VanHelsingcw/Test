import java.io.File;
import java.io.IOException;

public class Test6 {
    public static void main(String[] args) throws IOException {
        File file=new File("D:\\aaa");
        System.out.println(file.getName()+"是否存在:"+file.exists());
        file.mkdir();
        File file2=new File("D:\\aaa\\b.txt");
        file2.createNewFile();
        System.out.println("文件大小:"+file2.length());
        System.out.println("文件名:"+file2.getName());
        System.out.println("文件绝对路径及其父路径:"+file2.getAbsolutePath());
    }
}