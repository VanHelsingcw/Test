import java.io.File;

public class Test5 {
    public static void main(String[] args) {
        File file=new File("D:\\aaa\\b.txt");
        file.delete();
        File file2=new File("D:\\aaa");
        file2.delete();
    }
}
