import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test8 {
    public static void main(String[] args) {
        ExecutorService service= Executors.newFixedThreadPool(2);
        MyRunnable r=new MyRunnable("陈");
        MyRunnable s=new MyRunnable("吴");
        service.submit(r);
        service.submit(r);
        service.submit(s);
        service.shutdown();
    }
}
