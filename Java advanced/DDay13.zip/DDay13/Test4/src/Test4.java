import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test4 {
    public static void main(String[] args) {
        Stream<String> stream=Stream.of("黄药师","冯蘅","郭靖","黄蓉","郭芙","郭襄","郭破虏");
        Stream<String> stream1=stream.filter(s -> s.startsWith("郭"));
        String[] string=stream1.toArray(String[]::new);
        for(String string1:string){
            System.out.println(string1);
        }
    }
}
