import java.util.stream.Stream;
import java.lang.Integer;
import java.lang.Math;
public class Test6 {
    public static void main(String[] args) {
        String[] string={"1","-2","-3","4","5"};
        Stream<Integer> stream=Stream.of(string).map(Integer::parseInt);
        stream.map(Math::abs).forEach(System.out::println);
    }
}
