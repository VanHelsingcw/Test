import java.io.FileOutputStream;
import java.io.IOException;

public class Test2 {
    public static void main(String[] args) throws IOException {
        FileOutputStream fos=new FileOutputStream("C:\\Users\\ASUS\\Desktop\\c.txt");
        byte[] b="i love java".getBytes();
        for(int i=0;i<b.length;i++){
            fos.write(b,i,1);
        }
        fos.close();
    }
}
