import java.io.FileInputStream;
import java.io.IOException;

public class Test5 {
    public static void main(String[] args) throws IOException {
        FileInputStream fis=new FileInputStream("C:\\Users\\ASUS\\Desktop\\a.txt");
        byte[] b=new byte[1];
        int len;
        while((len=fis.read(b))!=-1){
            System.out.println(new String(b,0,len));
        }
        fis.close();
    }
}
