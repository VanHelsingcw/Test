import java.io.FileOutputStream;
import java.io.IOException;

public class Test3 {
    public static void main(String[] args) throws IOException {
        FileOutputStream fos=new FileOutputStream("C:\\Users\\ASUS\\Desktop\\b.txt",true);
        byte[] b="I love java".getBytes();
        byte[] c="\r\n".getBytes();
        fos.write(c);
        for(int i=0;i<5;i++) {
            fos.write(b);
            fos.write(c);
        }
        fos.close();
    }
}
