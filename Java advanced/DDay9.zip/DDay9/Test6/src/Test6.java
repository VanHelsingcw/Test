import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test6 {
    public static void main(String[] args) throws IOException {
        File file=new File("C:\\Users\\ASUS\\Desktop\\a.png");
        FileInputStream fis=new FileInputStream(file);
        File files=new File("C:\\Users\\ASUS\\Desktop\\b.png");
        FileOutputStream fos=new FileOutputStream(files);
        int len;
        while((len=fis.read())!=-1){
            fos.write(len);
        }
        fis.close();
        fos.close();
    }
}
