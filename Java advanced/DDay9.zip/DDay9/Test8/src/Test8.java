import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;

public class Test8 {
    public static void main(String[] args) throws FileNotFoundException,IOException {
        Properties pro=new Properties();
        pro.load(new FileInputStream("C:\\Users\\ASUS\\Desktop\\score.txt"));
        pro.setProperty("lisi","100");
        Set<String> strings=pro.stringPropertyNames();
        for(String key:strings){
            System.out.println(key+"---"+pro.getProperty(key));
        }
    }
}
