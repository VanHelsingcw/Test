import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Test7 {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File file=new File("C:\\Users\\ASUS\\Desktop\\Info.txt");
        FileWriter fw=new FileWriter(file);
        Scanner sc=new Scanner(System.in);
        String string=sc.nextLine();
        fw.write(string);
        fw.write("\r\n");
        fw.flush();
        while(!string.equals("886")){
             string = sc.nextLine();
             fw.write(string);
             fw.write("\r\n");
             fw.flush();
        }
        fw.close();
    }
}
