import java.util.Calendar;

public class Test7 {
    public static void main(String[] args){
        Calendar cal=Calendar.getInstance();
        cal.set(2018,01,14);
        int week=cal.get(Calendar.DAY_OF_WEEK)-1;
        System.out.println("2018年2月14日为星期"+week);
    }
}
