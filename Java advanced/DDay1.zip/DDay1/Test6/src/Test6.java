import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Test6 {
    public static void main(String[] args){
        SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal=Calendar.getInstance();
        cal.set(2018,02,04);
        Date date=cal.getTime();
        String a=s.format(date);
        System.out.println(a);
        SimpleDateFormat sb=new SimpleDateFormat("yyyy年MM月dd日");
        String b=sb.format(date);
        System.out.println(b);
    }
}
