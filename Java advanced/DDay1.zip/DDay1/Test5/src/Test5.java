import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test5 {
    public static void main(String[] args){
        Date date=new Date();
        DateFormat a= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String s=a.format(date);
        System.out.println(s);
    }
}
