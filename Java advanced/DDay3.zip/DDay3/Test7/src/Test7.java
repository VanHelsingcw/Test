import java.util.ArrayList;
import java.util.Collections;

public class Test7 {
    public static void main(String[] args){
        ArrayList<String> list=new ArrayList<>();
        Collections.addAll(list,"张三","李四","王五","二丫","钱六","孙七");
        System.out.println(list);
        list.set(3,"王小丫");
        System.out.println(list);
    }
}
