import java.util.Collections;
import java.util.HashSet;

public class Test6 {
    public static void main(String[] args){
        Student a=new Student(20,"陈");
        Student b=new Student(19,"吴");
        Student c=new Student(21,"杨");
        Student d=new Student(20,"陈");
        HashSet<Student> list=new HashSet<>();
        list.add(a);
        list.add(b);
        list.add(c);
        list.add(d);
        System.out.println(list);
    }
}
