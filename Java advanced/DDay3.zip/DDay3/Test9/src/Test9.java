import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Test9 {
    public static void main(String[] args){
        ArrayList<Integer> list=new ArrayList<>();
        Collections.addAll(list,33,11,77,55);
        Collections.sort(list);
        System.out.print(list);
    }
}
