import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class Test8 {
    public static void main(String[] args){
        LinkedHashSet<String> a=new LinkedHashSet<>();
        Collections.addAll(a,"王昭君","王昭君","西施","杨玉环","貂蝉");
        Iterator<String> b=a.iterator();
        while (b.hasNext()){
            System.out.print(b.next()+" ");
        }
        System.out.println();
        for(String c:a){
            System.out.print(c+" ");
        }
        System.out.println();
    }
}
