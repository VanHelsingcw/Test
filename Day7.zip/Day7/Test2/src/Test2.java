import java.util.ArrayList;
import java.util.Scanner;
public class Test2 {
    public static void main(String[] args) {
        String name;
        int age;
        ArrayList<Student> List = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        System.out.println("1.录入信息 0.退出");
        int i = sc.nextInt();
        while (i == 1) {
            Scanner in = new Scanner(System.in);
            System.out.println("请输入姓名:");
            name = in.nextLine();
            System.out.println("请输入年龄:");
            age = sc.nextInt();1
            Student s = new Student(name, age);
            List.add(s);
            System.out.println("1.录入信息 0.退出");
            i = sc.nextInt();
        }
        System.out.println("录入完毕");
        for (int j = 0; j < List.size(); j++) {
            System.out.println("学生姓名=" + List.get(j).getname() + ",年龄=" + List.get(j).getAge());
        }
    }
}
