import java.util.ArrayList;
public class MyList {
    private ArrayList<Integer> MyList=new ArrayList<>();
    public MyList(){}
    public void add(int n){
        MyList.add(n);
    }
    public void remove(){
        System.out.println("获取元素:");
        System.out.println(MyList.get(MyList.size()-1));
        MyList.remove(MyList.size()-1);
    }
    public void show(){
        System.out.print("["+MyList.get(0));
        for(int i=1;i<MyList.size();i++) {
            System.out.print(","+MyList.get(i));
        }
        System.out.println("]");
    }
}
