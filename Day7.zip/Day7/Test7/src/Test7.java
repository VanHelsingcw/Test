import java.util.Scanner;
public class Test7 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("请输入要添加元素的个数");
        int n=sc.nextInt();
        MyList s=new MyList();
        for(int i=0;i<n;i++){
            int k=sc.nextInt();
            s.add(k);
        }
        System.out.println("添加元素后:");
        s.show();
        s.remove();
        System.out.println("获取元素后:");
        s.show();
    }
}
