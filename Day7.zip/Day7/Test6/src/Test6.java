import java.util.Random;
import java.util.Scanner;

public class Test6 {
    public static void main(String[] args){
        String a[]=new String[]{"黑桃","红桃","梅花","方片"};
        String b[]=new String[]{"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
        String c[]=new String[52];
        int k=0;
        for(int i=0;i<4;i++){
            for(int j=0;j<13;j++){
                c[k]=a[i]+b[j];
                k++;
            }
        }
        Scanner sc=new Scanner(System.in);
        System.out.println("输入你要的随机牌的数量");
        int n=sc.nextInt();
        System.out.println("随机" + n + "张牌:");
        if(n>52) System.out.println("超越范围,无法获取");
        else {
            for (int j = 0; j < n; j++) {
                Random r = new Random();
                int m = r.nextInt(52) + 1;
                System.out.print(c[m] + " ");
            }
        }
    }
}
